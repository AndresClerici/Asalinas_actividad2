package py.edu.uaa.pooj.asalinas;

import java.util.List;

public class Libro {	
	
	private String titulo;
	private List<Autor> revistas;
	private String editorial;
	
	public Libro() {
		
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public List<Autor> getRevistas() {
		return revistas;
	}

	public void setRevistas(List<Autor> revistas) {
		this.revistas = revistas;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	//by: andrewSalinas
}
