package py.edu.uaa.pooj.asalinas;

public class Alumno extends Lector{
	
	private String libretaUniversitaria;

	public String getLibretaUniversitaria() {
		return libretaUniversitaria;
	}

	public void setLibretaUniversitaria(String libretaUniversitaria) {
		this.libretaUniversitaria = libretaUniversitaria;
	}

	//by: andrewSalinas
}
