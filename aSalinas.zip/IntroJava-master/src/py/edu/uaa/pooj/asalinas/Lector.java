package py.edu.uaa.pooj.asalinas;

public class Lector extends Persona{
	
	private Integer nroLector;
	private String telefonoContacto;
	
	public Lector() {
		
	}
	
	public Integer getNroLector() {
		return nroLector;
	}
	public void setNroLector(Integer nroLector) {
		this.nroLector = nroLector;
	}
	public String getTelefonoContacto() {
		return telefonoContacto;
	}
	public void setTelefonoContacto(String telefonoContacto) {
		this.telefonoContacto = telefonoContacto;
	}
	
	//by: andrewSalinas
}
