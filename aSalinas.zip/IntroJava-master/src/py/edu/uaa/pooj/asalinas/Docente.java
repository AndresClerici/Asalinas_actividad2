package py.edu.uaa.pooj.asalinas;

public class Docente extends Lector{

	public Docente(){
		
	}
	
}
