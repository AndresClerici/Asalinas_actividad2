package py.edu.uaa.pooj.asalinas;

public class test {
	
	public static void main(String[] args) {
		
		String nombre = "Andres Salinas";		
		System.out.println("Hola mundo!! desde" + nombre);
		
		System.err.println();
	}
	
	//by: andrewSalinas
}
