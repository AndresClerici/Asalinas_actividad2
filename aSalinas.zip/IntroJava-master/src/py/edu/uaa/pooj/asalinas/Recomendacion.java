package py.edu.uaa.pooj.asalinas;

public class Recomendacion {
	
	//No se como se tiene que instanciar, creo que eso significaba la flechita rayadita 
	//seg�n google = Reclamo reclamo = new Reclamo(); no creo que este bien '(:/)' (sorry teacher) 
	
	private Docente docente;
	private Libro libro;
	
	public Docente getDocente() {
		return docente;
	}
	public void setDocente(Docente docente) {
		this.docente = docente;
	}
	public Libro getLibro() {
		return libro;
	}
	public void setLibro(Libro libro) {
		this.libro = libro;
	}
	
	//by: andrewSalinas	
}
