package py.edu.uaa.pooj.asalinas;

public class Ejemplar {
	
	private Edicion edicion;

	public Ejemplar() {
		
	}
	
	public Edicion getEdicion() {
		return edicion;
	}
	public void setEdicion(Edicion edicion) {
		this.edicion = edicion;
	}
	
	//by: andrewSalinas
}
