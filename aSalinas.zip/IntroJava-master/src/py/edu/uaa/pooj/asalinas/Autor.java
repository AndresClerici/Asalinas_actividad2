package py.edu.uaa.pooj.asalinas;

public class Autor extends Persona{
	
	private String nombreFantasia;	
	
	public Autor() {
		
	}
	
	public void consultarLibroPorAutor() {
		
	}
	
	public String getNombreFantasia() {
		return nombreFantasia;
	}
	public void setNombreFantasia(String nombreFantasia) {
		this.nombreFantasia = nombreFantasia;
	}	
	
	//by: andrewSalinas
}
