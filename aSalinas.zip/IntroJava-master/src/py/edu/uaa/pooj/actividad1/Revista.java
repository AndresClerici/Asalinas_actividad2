package py.edu.uaa.pooj.actividad1;

public class Revista {
	private String nombre;
	private Integer nroEdicion;
	private Integer precio;

	public Revista() {

	}
	
	public void agregarRevista(){
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getNroEdicion() {
		return nroEdicion;
	}

	public void setNroEdicion(Integer nroEdicion) {
		this.nroEdicion = nroEdicion;
	}

	public Integer getPrecio() {
		return precio;
	}

	public void setPrecio(Integer precio) {
		this.precio = precio;
	}

}
