package py.edu.uaa.pooj.actividad1;

public class PeriodoPublicacion {
	private String nombrePeriodo;
	private Integer frecuenciaDias;

	public PeriodoPublicacion(){
		
	}
	
	public void agregarPeriodoPublicacion(){
		
	}
	
	public String getNombrePeriodo() {
		return nombrePeriodo;
	}

	public void setNombrePeriodo(String nombrePeriodo) {
		this.nombrePeriodo = nombrePeriodo;
	}

	public Integer getFrecuenciaDias() {
		return frecuenciaDias;
	}

	public void setFrecuenciaDias(Integer frecuenciaDias) {
		this.frecuenciaDias = frecuenciaDias;
	}

}
